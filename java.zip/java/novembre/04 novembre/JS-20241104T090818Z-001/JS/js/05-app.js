class Person { //pascal Naming Convention
    

    // Il est appellé automatiquement lors de l'instance d'une classe
 constructor(name, firstName) { // permet d'initialiser des valeurs pour nos champs (propriétés objet qu'on aura)
    this.name = name;
    this.firstName = firstName;
 }

 sayHello() {
    console.log("Hey Salut, je m'appel " + this.firstName + " " + this.name);
 }
}

const albano = new Person("Albano", "Ayme"); //j'ai créé des objest a partir de l'instance de la class person
const wajdi = new Person("Wajdi", "rouafi");
const florian = new Person("Florian", "Santantonio");

albano.sayHello();
wajdi.sayHello();
florian.sayHello();