// funtion


function sayHello() {
    console.log("Hello !");
}


function squardNumber() {
    return 2 * 2; // return statement
    // je peux rien avoir apres le return
}

function SquareNbr(number) {
    return number * number;

}

SquareNbr(2);
SquareNbr(12);
SquareNbr(22);